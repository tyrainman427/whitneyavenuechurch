from django.apps import AppConfig


class WhitneyappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'whitneyapp'
