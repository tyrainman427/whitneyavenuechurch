from django.db import models

# Create your models here.
class Event(models.Model):
    title = models.TextField(max_length=250)
    location = models.TextField(max_length=100)
    more_info = models.TextField(max_length=100)
    days = models.TextField(max_length=100)
    month = models.TextField(max_length=100)
    day_of_week = models.TextField(max_length=100)
    dates_duration = models.TextField(max_length=100)
    
    
    
    